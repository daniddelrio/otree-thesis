from .globals import *

PART = PRACTICE
NUM_ROUNDS = 5
NAME_IN_CARTEL = "cartelpractice"
