from .globals import *

PART = ACTUAL
NUM_ROUNDS = 12
NAME_IN_CARTEL = "cartelgame"
